Scripts used for the performance evaluation (not part of the C++ project).
Python 3; make_charts.py also needs matplotlib (pip install matplotlib).

1. Build the solver:         bash build-TSPsolver.sh
2. Measure and check tours:  python3 measure.py <path/to/build/TSPsolver> <path/to/TSP-instances> results.json
3. Draw the two graphs:      python3 make_charts.py results.json graphs

measure.py runs each method 3 times per instance (Held-Karp only up to 24 cities),
keeps the median wall-clock time of the whole program and the peak memory, checks that
each tour is valid, computes its length with its own TSPLIB distance formulas, and
divides it by the known optimal length. Times depend on the machine.
