#!/usr/bin/env python3
"""Measure the three methods of TSPsolver on the TSPLIB instances.

For each instance and method it
  1. runs ./build/TSPsolver 3 times and keeps the median wall-clock time,
     and the peak memory of the process,
  2. reads the .tour file the solver wrote, checks that it is a valid tour
     (each city exactly once), and computes its length with its own
     implementation of the TSPLIB distance formulas,
  3. divides the length by the known optimal length (TSPLIB).
The results are saved in a JSON file, used by make_charts.py.

Usage:
  python3 measure.py <path/to/TSPsolver> <path/to/TSP-instances> [results.json]
Python 3 standard library only.
"""
import json
import math
import os
import statistics
import subprocess
import sys
import tempfile
import time

REPS = 3
METHODS = ["trivial", "nearest-neighbor", "held-karp"]
HELD_KARP_MAX = 24
# Optimal tour lengths from the TSPLIB library (to compare the tours with).
OPTIMUM = {
    "burma14": 3323, "ulysses16": 6859, "gr17": 2085, "gr21": 2707, "gr24": 1272,
    "dantzig42": 699, "att48": 10628, "gr48": 5046, "berlin52": 7542, "st70": 675,
    "eil76": 538, "pr76": 108159, "ch130": 6110, "pr299": 48191, "pr1002": 259045,
}


def read_instance(path):
    """Returns (header dict, coordinates list, weights list)."""
    header, coords, weights, section = {}, [], [], None
    for raw in open(path):
        line = raw.strip()
        if not line or line == "EOF":
            continue
        if line.endswith("_SECTION"):
            section = line
        elif ":" in line:
            key, _, value = line.partition(":")
            header[key.strip()] = value.strip()
        elif section == "NODE_COORD_SECTION":
            _, x, y = line.split()[:3]
            coords.append((float(x), float(y)))
        elif section == "EDGE_WEIGHT_SECTION":
            weights += [int(t) for t in line.split()]
    return header, coords, weights


def geo_radians(x):
    degrees = int(x)
    return math.pi * (degrees + 5.0 * (x - degrees) / 3.0) / 180.0


def make_distance(header, coords, weights):
    """Returns a function d(i, j) for cities numbered from 0 (TSPLIB rules)."""
    kind = header["EDGE_WEIGHT_TYPE"]
    n = int(header["DIMENSION"])
    if kind == "EXPLICIT":                       # LOWER_DIAG_ROW
        matrix = [[0] * n for _ in range(n)]
        k = 0
        for i in range(n):
            for j in range(i + 1):
                matrix[i][j] = matrix[j][i] = weights[k]
                k += 1
        return lambda i, j: matrix[i][j]

    def d(i, j):
        (x1, y1), (x2, y2) = coords[i], coords[j]
        if kind == "GEO":
            lat1, lon1, lat2, lon2 = geo_radians(x1), geo_radians(y1), geo_radians(x2), geo_radians(y2)
            q1, q2, q3 = math.cos(lon1 - lon2), math.cos(lat1 - lat2), math.cos(lat1 + lat2)
            return int(6378.388 * math.acos(0.5 * ((1 + q1) * q2 - (1 - q1) * q3)) + 1.0)
        dx, dy = x1 - x2, y1 - y2
        if kind == "EUC_2D":
            return int(math.sqrt(dx * dx + dy * dy) + 0.5)
        r = math.sqrt((dx * dx + dy * dy) / 10.0)    # ATT
        t = int(r + 0.5)
        return t + 1 if t < r else t
    return d


def read_tour(path):
    """Returns the list of cities of a .tour file (checks the format)."""
    lines = [l.strip() for l in open(path) if l.strip()]
    assert lines[1] == "TYPE : TOUR" and lines[3] == "TOUR_SECTION", "bad tour header"
    assert lines[-2] == "-1" and lines[-1] == "EOF", "bad tour end"
    return [int(x) for x in lines[4:-2]]


def run_solver(solver, instance, output, method):
    """Runs the solver once; returns (seconds, peak memory in MB)."""
    start = time.perf_counter()
    process = subprocess.Popen([solver, instance, output, "-m", method],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _, status, usage = os.wait4(process.pid, 0)   # usage.ru_maxrss = peak memory (kB)
    seconds = time.perf_counter() - start
    if status != 0:
        raise RuntimeError(f"{method} failed on {instance}")
    return seconds, usage.ru_maxrss / 1024.0


def main():
    solver, folder = os.path.abspath(sys.argv[1]), sys.argv[2]
    results_file = sys.argv[3] if len(sys.argv) > 3 else "results.json"
    files = {}
    for root, _, names in os.walk(folder):
        for name in names:
            if name.endswith(".tsp"):
                files[name[:-4]] = os.path.join(root, name)

    results = {}
    tmp = tempfile.mkdtemp()
    for name in sorted(OPTIMUM, key=lambda n: (int("".join(c for c in n if c.isdigit()) or 0), n)):
        header, coords, weights = read_instance(files[name])
        n = int(header["DIMENSION"])
        dist = make_distance(header, coords, weights)
        for method in METHODS:
            if method == "held-karp" and n > HELD_KARP_MAX:
                continue
            output = os.path.join(tmp, f"{method}_{name}.tour")
            times, memories = [], []
            for _ in range(REPS):
                seconds, memory = run_solver(solver, files[name], output, method)
                times.append(seconds)
                memories.append(memory)
            tour = read_tour(output)
            valid = sorted(tour) == list(range(1, n + 1))
            length = sum(dist(tour[i] - 1, tour[(i + 1) % n] - 1) for i in range(n))
            results[f"{method}|{name}"] = {
                "n": n, "valid": valid, "length": length, "opt": OPTIMUM[name],
                "t": statistics.median(times), "mem": max(memories)}
            print(f"{method:<17}{name:<10} n={n:<5} valid={valid} length={length:<7} "
                  f"x opt={length / OPTIMUM[name]:.2f}  {statistics.median(times) * 1000:8.1f} ms", flush=True)
    json.dump(results, open(results_file, "w"), indent=1)
    print("saved", results_file)


if __name__ == "__main__":
    main()
