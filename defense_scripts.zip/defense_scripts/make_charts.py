#!/usr/bin/env python3
"""Draws the two graphs of the report from the file made by measure.py.

Usage:
  python3 make_charts.py [results.json] [output_folder]
Needs matplotlib (pip install matplotlib).
"""
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

results_file = sys.argv[1] if len(sys.argv) > 1 else "results.json"
out = sys.argv[2] if len(sys.argv) > 2 else "."
os.makedirs(out, exist_ok=True)

BLUE, ORANGE, GREEN = "#2a78d6", "#eb6834", "#1baf7a"   # trivial, nearest neighbor, Held-Karp
res = json.load(open(results_file))
names = sorted({k.split("|")[1] for k in res}, key=lambda n: (res["trivial|" + n]["n"], n))


def tidy(ax):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.grid(axis="y", color="#e4e3df", linewidth=0.7)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)


# Graph 1: tour length / optimal length, for the trivial method and nearest neighbor.
fig, ax = plt.subplots(figsize=(7.4, 3.6), dpi=220)
width = 0.38
positions = range(len(names))
trivial = [res["trivial|" + n]["length"] / res["trivial|" + n]["opt"] for n in names]
nearest = [res["nearest-neighbor|" + n]["length"] / res["nearest-neighbor|" + n]["opt"] for n in names]
ax.bar([i - width / 2 for i in positions], trivial, width, color=BLUE, edgecolor="white", label="trivial")
ax.bar([i + width / 2 for i in positions], nearest, width, color=ORANGE, edgecolor="white", label="nearest neighbor")
ax.axhline(1, color="#52514e", linewidth=1, linestyle="--", label="optimal tour (= 1)")
ax.set_xticks(list(positions))
ax.set_xticklabels(names, rotation=45, ha="right", fontsize=9)
ax.set_ylabel("tour length / optimal length")
tidy(ax)
ax.legend(frameon=False, loc="upper left")
fig.tight_layout()
fig.savefig(os.path.join(out, "quality.png"))

# Graph 2: time of Held-Karp (only the instances it can solve).
held_karp = [n for n in names if "held-karp|" + n in res]
seconds = [res["held-karp|" + n]["t"] for n in held_karp]
fig, ax = plt.subplots(figsize=(7.4, 3.0), dpi=220)
ax.bar(range(len(held_karp)), seconds, 0.55, color=GREEN, edgecolor="white")
for i, t in enumerate(seconds):
    ax.text(i, t + max(seconds) * 0.02, f"{t:.1f} s" if t >= 1 else f"{t * 1000:.0f} ms", ha="center")
ax.set_xticks(range(len(held_karp)))
ax.set_xticklabels([f"{n}\n{res['held-karp|' + n]['n']} cities" for n in held_karp])
ax.set_ylabel("time (seconds)")
tidy(ax)
fig.tight_layout()
fig.savefig(os.path.join(out, "heldkarp_time.png"))
print("graphs saved in", os.path.abspath(out))
